import { useState, useRef, useCallback } from 'react'
import { Loader2, ShieldCheck, Upload, FileText, X, CheckCircle2, AlertCircle } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import { useAccount } from 'wagmi'
import { buildTxExplorerUrl } from '@/onchain-facts'
import { CHAIN_ID } from '@/hooks/useRealEstateContract'

type DocType = 'passport' | 'national_id' | 'drivers_license' | 'residence_permit'

const DOC_TYPES: { value: DocType; label: string; icon: string }[] = [
  { value: 'passport',          label: 'Passport',         icon: '🛂' },
  { value: 'national_id',       label: 'National ID',      icon: '🪪' },
  { value: 'drivers_license',   label: "Driver's License", icon: '🚗' },
  { value: 'residence_permit',  label: 'Residence Permit', icon: '🏠' },
]

type Step = 'idle' | 'uploading' | 'approving' | 'done' | 'error'

function DropZone({ file, onFile, onClear }: { file: File | null; onFile: (f: File) => void; onClear: () => void }) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); setDragging(false)
    const f = e.dataTransfer.files[0]; if (f) onFile(f)
  }, [onFile])

  if (file) {
    const isImg = file.type.startsWith('image/')
    return (
      <div className="relative rounded-2xl border-2 overflow-hidden" style={{ borderColor: 'var(--success)', background: 'rgba(26,128,71,0.04)' }}>
        {isImg
          ? <img src={URL.createObjectURL(file)} alt="Document" className="w-full max-h-40 object-contain" />
          : (
            <div className="flex items-center gap-3 p-4">
              <FileText className="size-6 shrink-0" style={{ color: 'var(--success)' }} />
              <div>
                <div className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{file.name}</div>
                <div className="text-xs" style={{ color: 'var(--muted)' }}>{(file.size / 1024).toFixed(0)} KB · PDF</div>
              </div>
            </div>
          )
        }
        <button onClick={onClear} className="absolute top-2 right-2 flex size-6 items-center justify-center rounded-full" style={{ background: 'rgba(255,255,255,0.85)' }}>
          <X className="size-3.5" style={{ color: 'var(--ink-2)' }} />
        </button>
        <div className="px-3 py-1.5 text-xs font-medium flex items-center gap-1" style={{ color: 'var(--success)', background: 'rgba(26,128,71,0.06)' }}>
          <CheckCircle2 className="size-3" /> Document ready to submit
        </div>
      </div>
    )
  }

  return (
    <div
      onDragOver={e => { e.preventDefault(); setDragging(true) }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
      className="cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition-all"
      style={{ borderColor: dragging ? 'var(--accent)' : 'var(--border)', background: dragging ? 'rgba(18,45,69,0.04)' : 'var(--surface-muted)' }}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,application/pdf"
        className="sr-only"
        onChange={e => { const f = e.target.files?.[0]; if (f) onFile(f) }}
      />
      <div className="flex flex-col items-center gap-3">
        <div className="flex size-12 items-center justify-center rounded-2xl" style={{ background: 'rgba(18,45,69,0.07)' }}>
          <Upload className="size-5" style={{ color: 'var(--accent)' }} />
        </div>
        <div>
          <div className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>Drop your document here</div>
          <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>or click to browse · JPEG, PNG, WebP, PDF · max 20 MB</div>
        </div>
      </div>
    </div>
  )
}

export default function KycFlow({ onComplete }: { onComplete?: () => void }) {
  const { address } = useAccount()
  const [step, setStep] = useState<Step>('idle')
  const [docType, setDocType] = useState<DocType | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [txHash, setTxHash] = useState<`0x${string}` | null>(null)
  const [errorMsg, setErrorMsg] = useState('')

  const handleSubmit = async () => {
    if (!file || !docType || !address) return
    setStep('uploading')
    setErrorMsg('')

    const formData = new FormData()
    formData.append('wallet', address)
    formData.append('docType', docType)
    formData.append('document', file)

    let data: { ok?: boolean; txHash?: `0x${string}`; error?: string }
    try {
      const res = await fetch('/api/kyc/submit', { method: 'POST', body: formData })
      data = await res.json() as typeof data

      if (!res.ok || !data.ok) {
        setErrorMsg(data.error ?? 'Verification failed. Please try again.')
        setStep('error')
        return
      }
    } catch {
      setErrorMsg('Network error — KYC server may not be running.')
      setStep('error')
      return
    }

    // Server submitted the tx — now wait for it to confirm
    setStep('approving')

    if (data.txHash) {
      setTxHash(data.txHash)
      // Poll the RPC to wait for the tx receipt
      try {
        await waitForTx(data.txHash)
      } catch {
        // tx might still land; just proceed
      }
    }

    setStep('done')
    toast.success('KYC verified! You can now create listings and start transactions.')
    onComplete?.()
  }

  const reset = () => {
    setStep('idle'); setFile(null); setDocType(null); setTxHash(null); setErrorMsg('')
  }

  const busy = step === 'uploading' || step === 'approving'
  const txUrl = txHash ? buildTxExplorerUrl(CHAIN_ID, txHash) : null

  return (
    <div className="rounded-2xl overflow-hidden border" style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}>
      {/* Header */}
      <div className="flex items-center gap-2.5 px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="flex size-8 items-center justify-center rounded-xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
          <ShieldCheck className="size-4" style={{ color: 'var(--accent)' }} />
        </div>
        <div>
          <div className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>Identity Verification</div>
          <div className="text-xs" style={{ color: 'var(--muted)' }}>
            Upload any government ID — we'll approve your KYC instantly, no extra steps
          </div>
        </div>
      </div>

      <div className="p-5">
        <AnimatePresence mode="wait">

          {/* Idle — select doc type + upload */}
          {step === 'idle' && (
            <motion.div key="idle" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="space-y-4">
              {/* Doc type pills */}
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: 'var(--muted)' }}>Document type</p>
                <div className="grid grid-cols-2 gap-2">
                  {DOC_TYPES.map(dt => (
                    <button
                      key={dt.value}
                      onClick={() => setDocType(dt.value)}
                      className="flex items-center gap-2 rounded-xl px-3 py-2.5 border-2 transition-all text-left"
                      style={{
                        borderColor: docType === dt.value ? 'var(--accent)' : 'var(--border)',
                        background: docType === dt.value ? 'rgba(18,45,69,0.05)' : 'var(--surface-muted)',
                      }}
                    >
                      <span className="text-base">{dt.icon}</span>
                      <span className="text-sm font-medium" style={{ color: 'var(--ink)' }}>{dt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Upload */}
              <DropZone file={file} onFile={setFile} onClear={() => setFile(null)} />

              {/* Privacy note */}
              <div className="rounded-xl px-3 py-2 text-xs" style={{ background: 'rgba(18,45,69,0.04)', color: 'var(--muted)' }}>
                Your document is validated for format only and never stored. KYC is recorded directly on-chain to your wallet address.
              </div>

              <button
                disabled={!file || !docType}
                onClick={() => { void handleSubmit() }}
                className="w-full flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ background: 'var(--accent)' }}
              >
                <ShieldCheck className="size-4" /> Verify My Identity
              </button>
            </motion.div>
          )}

          {/* Processing */}
          {(step === 'uploading' || step === 'approving') && (
            <motion.div key="processing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="py-10 flex flex-col items-center gap-4 text-center">
              <div className="relative">
                <div className="flex size-16 items-center justify-center rounded-2xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
                  <ShieldCheck className="size-8" style={{ color: 'var(--accent)' }} />
                </div>
                <div className="absolute -top-1 -right-1 flex size-6 items-center justify-center rounded-full" style={{ background: 'var(--accent)' }}>
                  <Loader2 className="size-3.5 text-white animate-spin" />
                </div>
              </div>
              <div>
                <div className="font-semibold" style={{ color: 'var(--ink)' }}>
                  {busy && step === 'uploading' ? 'Validating document…' : 'Recording KYC on-chain…'}
                </div>
                <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
                  {busy && step === 'uploading'
                    ? 'Checking document format and generating authorization'
                    : 'Submitting transaction — this takes a few seconds'}
                </div>
              </div>
              <div className="flex gap-1.5">
                {(['Validating', 'Signing', 'Broadcasting'] as const).map((label, i) => {
                  const active = (step === 'uploading' && i === 0) || (step === 'approving' && i >= 1)
                  const done = step === 'approving' && i === 0
                  return (
                    <div key={label} className="flex items-center gap-1.5">
                      <div className="flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-medium transition-all"
                        style={{
                          background: done ? 'rgba(26,128,71,0.1)' : active ? 'rgba(18,45,69,0.08)' : 'var(--border)',
                          color: done ? 'var(--success)' : active ? 'var(--accent)' : 'var(--subtle)',
                        }}
                      >
                        {done && <CheckCircle2 className="size-3 mr-0.5" />}
                        {active && !done && <Loader2 className="size-3 mr-0.5 animate-spin" />}
                        {label}
                      </div>
                      {i < 2 && <div className="h-px w-2" style={{ background: 'var(--border)' }} />}
                    </div>
                  )
                })}
              </div>
            </motion.div>
          )}

          {/* Done */}
          {step === 'done' && (
            <motion.div key="done" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="py-8 flex flex-col items-center gap-3 text-center">
              <div className="flex size-16 items-center justify-center rounded-2xl" style={{ background: 'rgba(26,128,71,0.1)' }}>
                <CheckCircle2 className="size-9" style={{ color: 'var(--success)' }} />
              </div>
              <div>
                <div className="font-bold text-base" style={{ color: 'var(--ink)' }}>Identity Verified</div>
                <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
                  Full KYC (Level 2) recorded on-chain. You can now list properties and start transactions.
                </div>
              </div>
              {txUrl && (
                <a
                  href={txUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs underline"
                  style={{ color: 'var(--accent-hover)' }}
                >
                  View transaction on explorer
                </a>
              )}
            </motion.div>
          )}

          {/* Error */}
          {step === 'error' && (
            <motion.div key="error" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
              <div className="flex items-start gap-3 rounded-xl p-3.5" style={{ background: 'rgba(186,43,76,0.06)', border: '1px solid rgba(186,43,76,0.15)' }}>
                <AlertCircle className="size-5 shrink-0 mt-0.5" style={{ color: 'var(--danger)' }} />
                <div>
                  <div className="text-sm font-semibold" style={{ color: 'var(--danger)' }}>Verification failed</div>
                  <div className="text-xs mt-0.5 break-words" style={{ color: 'var(--muted)', maxWidth: '100%' }}>{errorMsg}</div>
                </div>
              </div>
              <button
                onClick={reset}
                className="w-full rounded-2xl py-3 text-sm font-semibold text-white"
                style={{ background: 'var(--accent)' }}
              >
                Try Again
              </button>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Lightweight tx confirmation poller (no wagmi needed here — backend already submitted)
// ---------------------------------------------------------------------------
async function waitForTx(hash: `0x${string}`, maxAttempts = 20): Promise<void> {
  const rpcUrl =
    (typeof import.meta !== 'undefined' && (import.meta as { env?: { VITE_ARC_TESTNET_RPC?: string } }).env?.VITE_ARC_TESTNET_RPC) ||
    'https://rpc.testnet.arc.io' // arc-studio-allow-onchain-literal

  for (let i = 0; i < maxAttempts; i++) {
    await new Promise(r => setTimeout(r, 2000))
    try {
      const res = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', method: 'eth_getTransactionReceipt', params: [hash], id: 1 }),
      })
      const json = await res.json() as { result?: { status?: string } | null }
      if (json.result?.status === '0x1') return // confirmed
    } catch { /* continue polling */ }
  }
}
