interface ReputationBarProps {
  score: number // 0–500
  showLabel?: boolean
}

export default function ReputationBar({ score, showLabel = true }: ReputationBarProps) {
  const pct = Math.min(100, (score / 500) * 100)
  const color = score >= 400 ? 'var(--success)' : score >= 250 ? '#1061a6' : 'var(--danger)'
  const label = score >= 400 ? 'Excellent' : score >= 300 ? 'Good' : score >= 200 ? 'Fair' : 'Low'

  return (
    <div className="flex flex-col gap-1.5">
      {showLabel && (
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium" style={{ color: 'var(--muted)' }}>Reputation</span>
          <span className="text-xs font-semibold tabular-nums" style={{ color }}>{score}/500 · {label}</span>
        </div>
      )}
      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--border)' }}>
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
    </div>
  )
}
