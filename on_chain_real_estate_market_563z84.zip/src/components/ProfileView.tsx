import { useState } from 'react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi'
import { Loader2, User, Star, Activity, AlertOctagon, Copy, ExternalLink } from 'lucide-react'
import { ConnectKitButton } from 'connectkit'
import { toast } from 'sonner'
import {
  useUserProfile, useUsdcBalance, formatUsdc,
  REAL_ESTATE_ABI, REAL_ESTATE_ADDRESS, CHAIN_ID, getTxUrl
} from '@/hooks/useRealEstateContract'
import { buildAddressExplorerUrl } from '@/onchain-facts'
import KycBadge from './KycBadge'
import ReputationBar from './ReputationBar'
import KycFlow from './KycFlow'

function AddressTag({ address }: { address: string }) {
  const short = `${address.slice(0, 6)}...${address.slice(-4)}`
  const copy = () => { void navigator.clipboard.writeText(address).then(() => toast.success('Address copied')) }
  return (
    <div className="flex items-center gap-2">
      <span className="mono text-xs tabular-nums" style={{ color: 'var(--ink-2)' }}>{short}</span>
      <button onClick={copy} className="p-1 rounded-lg hover:bg-black/5 transition-colors">
        <Copy className="size-3" style={{ color: 'var(--muted)' }} />
      </button>
      <a href={buildAddressExplorerUrl(CHAIN_ID, address)} target="_blank" rel="noopener noreferrer" className="p-1 rounded-lg hover:bg-black/5 transition-colors">
        <ExternalLink className="size-3" style={{ color: 'var(--muted)' }} />
      </a>
    </div>
  )
}

function StatCard({ label, value, sub, icon }: { label: string; value: string | number; sub?: string; icon: React.ReactNode }) {
  return (
    <div className="rounded-2xl p-3.5" style={{ background: 'var(--surface-muted)' }}>
      <div className="flex items-center gap-1.5 mb-2">
        <div className="flex size-5 items-center justify-center rounded-md" style={{ background: 'rgba(18,45,69,0.08)', color: 'var(--ink-2)' }}>
          {icon}
        </div>
        <span className="text-xs" style={{ color: 'var(--muted)' }}>{label}</span>
      </div>
      <div className="display text-xl font-bold tabular-nums" style={{ color: 'var(--ink)' }}>{value}</div>
      {sub && <div className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>{sub}</div>}
    </div>
  )
}

function LeaveReviewForm() {
  const { chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const { writeContract, data: hash, isPending } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash })
  const wrongChain = chainId !== CHAIN_ID

  const [form, setForm] = useState({
    target: '',
    id: '',
    isPurchase: true,
    score: 5,
    comment: '',
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return }
    writeContract({
      address: REAL_ESTATE_ADDRESS,
      abi: REAL_ESTATE_ABI,
      functionName: 'leaveReview',
      args: [
        form.target as `0x${string}`,
        BigInt(form.id || '0'),
        form.isPurchase,
        form.score,
        form.comment,
      ],
      chainId: CHAIN_ID,
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div>
        <label className="text-xs font-semibold uppercase tracking-widest mb-1 block" style={{ color: 'var(--muted)' }}>Counterparty Address</label>
        <input
          value={form.target}
          onChange={e => setForm(f => ({ ...f, target: e.target.value }))}
          placeholder="0x..."
          className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border mono"
          style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
          required
        />
      </div>

      <div className="flex gap-2">
        <div className="flex-1">
          <label className="text-xs font-semibold uppercase tracking-widest mb-1 block" style={{ color: 'var(--muted)' }}>Escrow / Agreement ID</label>
          <input
            inputMode="numeric"
            value={form.id}
            onChange={e => setForm(f => ({ ...f, id: e.target.value.replace(/\D/g, '') }))}
            placeholder="1"
            className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
            style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
            required
          />
        </div>
        <div>
          <label className="text-xs font-semibold uppercase tracking-widest mb-1 block" style={{ color: 'var(--muted)' }}>Type</label>
          <div className="flex gap-1 rounded-xl p-1" style={{ background: 'var(--surface-muted)' }}>
            {[{ v: true, l: 'Buy' }, { v: false, l: 'Rent' }].map(o => (
              <button
                key={String(o.v)}
                type="button"
                onClick={() => setForm(f => ({ ...f, isPurchase: o.v }))}
                className="rounded-lg px-2.5 py-1.5 text-xs font-medium transition-all"
                style={{
                  background: form.isPurchase === o.v ? 'white' : 'transparent',
                  color: form.isPurchase === o.v ? 'var(--ink)' : 'var(--muted)',
                }}
              >
                {o.l}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Star rating */}
      <div>
        <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: 'var(--muted)' }}>Rating</label>
        <div className="flex gap-1.5">
          {[1, 2, 3, 4, 5].map(s => (
            <button
              key={s}
              type="button"
              onClick={() => setForm(f => ({ ...f, score: s }))}
              className="size-8 flex items-center justify-center rounded-lg transition-all hover:scale-110"
              style={{ background: s <= form.score ? 'rgba(18,45,69,0.08)' : 'var(--surface-muted)' }}
            >
              <Star className="size-4" fill={s <= form.score ? 'var(--ink)' : 'none'} style={{ color: 'var(--ink-2)' }} />
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="text-xs font-semibold uppercase tracking-widest mb-1 block" style={{ color: 'var(--muted)' }}>Comment (optional)</label>
        <textarea
          value={form.comment}
          onChange={e => setForm(f => ({ ...f, comment: e.target.value }))}
          placeholder="Great transaction, smooth process…"
          className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border resize-none"
          style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
          rows={2}
          maxLength={280}
        />
      </div>

      {isSuccess && hash ? (
        <div className="rounded-xl p-3 text-center" style={{ background: 'rgba(26,128,71,0.06)' }}>
          <p className="text-sm font-medium" style={{ color: 'var(--success)' }}>Review submitted!</p>
          <a href={getTxUrl(hash)} target="_blank" rel="noopener noreferrer" className="text-xs underline mt-1 block" style={{ color: 'var(--accent-hover)' }}>View on explorer</a>
        </div>
      ) : (
        <button
          type="submit"
          disabled={isPending || isConfirming}
          className="w-full rounded-2xl py-3 text-sm font-semibold text-white disabled:opacity-40 disabled:cursor-not-allowed transition-all hover:scale-[1.01]"
          style={{ background: 'var(--accent)' }}
        >
          {isPending ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Confirm in wallet...</span>
            : isConfirming ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Submitting...</span>
            : 'Submit Review'}
        </button>
      )}
    </form>
  )
}

export default function ProfileView() {
  const { address } = useAccount()
  const { data: profile, refetch: refetchProfile } = useUserProfile(address)
  const { data: balanceRaw } = useUsdcBalance(address)
  const [showReviewForm, setShowReviewForm] = useState(false)

  if (!address) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 flex flex-col items-center gap-4 text-center">
        <User className="size-8" style={{ color: 'var(--muted)' }} />
        <p className="font-medium" style={{ color: 'var(--ink)' }}>Connect your wallet to view your profile</p>
        <ConnectKitButton />
      </div>
    )
  }

  const kycLevel = profile?.kycLevel ?? 0
  const repScore = profile?.reputationScore ?? 250
  const txCount = Number(profile?.totalTransactions ?? 0n)
  const disputeCount = Number(profile?.disputeCount ?? 0n)
  const reviewCount = Number(profile?.reviewCount ?? 0n)
  const isBanned = profile?.isBanned ?? false
  const balance = balanceRaw ?? 0n

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="display text-2xl font-bold tracking-tight" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>My Profile</h1>
        <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Your on-chain identity and reputation.</p>
      </div>

      {/* Identity card */}
      <div className="rounded-2xl p-5 mb-4 border" style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)', boxShadow: '0 2px 12px rgba(18,45,69,0.06)' }}>
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <div className="flex size-10 items-center justify-center rounded-2xl mb-2" style={{ background: 'var(--accent)' }}>
              <User className="size-5 text-white" />
            </div>
            <AddressTag address={address} />
          </div>
          <KycBadge level={kycLevel} />
        </div>

        {isBanned && (
          <div className="mb-4 flex items-center gap-2 rounded-xl px-3 py-2" style={{ background: 'rgba(186,43,76,0.08)' }}>
            <AlertOctagon className="size-4" style={{ color: 'var(--danger)' }} />
            <span className="text-sm font-medium" style={{ color: 'var(--danger)' }}>Account restricted</span>
          </div>
        )}

        <div className="mb-4">
          <ReputationBar score={repScore} />
        </div>

        {/* USDC balance */}
        <div className="rounded-xl p-3" style={{ background: 'var(--surface-muted)' }}>
          <div className="flex items-center justify-between">
            <span className="text-xs" style={{ color: 'var(--muted)' }}>USDC Balance</span>
            <span className="display text-lg font-bold tabular-nums" style={{ color: 'var(--ink)' }}>{formatUsdc(balance)}</span>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <StatCard label="Transactions" value={txCount} icon={<Activity className="size-3" />} />
        <StatCard label="Reviews" value={reviewCount} sub="received" icon={<Star className="size-3" />} />
        <StatCard label="Disputes" value={disputeCount} icon={<AlertOctagon className="size-3" />} />
      </div>

      {/* KYC flow — shown when not yet verified */}
      {kycLevel === 0 && (
        <div className="mb-6">
          <KycFlow onComplete={() => { void refetchProfile() }} />
        </div>
      )}

      {/* Leave Review */}
      <div className="rounded-2xl overflow-hidden border" style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}>
        <button
          onClick={() => setShowReviewForm(v => !v)}
          className="w-full flex items-center justify-between px-4 py-3.5 text-sm font-semibold transition-colors hover:bg-black/[0.02]"
          style={{ color: 'var(--ink)' }}
        >
          <div className="flex items-center gap-2">
            <Star className="size-4" style={{ color: 'var(--accent)' }} />
            Leave a Review
          </div>
          <span className="text-xs" style={{ color: 'var(--muted)' }}>{showReviewForm ? 'Close' : 'Open'}</span>
        </button>
        {showReviewForm && (
          <div className="px-4 pb-5 border-t" style={{ borderColor: 'var(--border)' }}>
            <div className="pt-4">
              <LeaveReviewForm />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
