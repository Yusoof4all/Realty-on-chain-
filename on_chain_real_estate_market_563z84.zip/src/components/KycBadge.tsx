import { ShieldCheck, ShieldAlert, Shield } from 'lucide-react'

interface KycBadgeProps {
  level: number
  score?: number
  size?: 'sm' | 'md'
}

export default function KycBadge({ level, score, size = 'md' }: KycBadgeProps) {
  const isSmall = size === 'sm'

  if (level === 0) {
    return (
      <span className={`inline-flex items-center gap-1 rounded-full font-medium ${isSmall ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'}`}
        style={{ background: 'rgba(186,43,76,0.08)', color: 'var(--danger)' }}>
        <Shield className={isSmall ? 'size-2.5' : 'size-3'} />
        No KYC
      </span>
    )
  }
  if (level === 1) {
    return (
      <span className={`inline-flex items-center gap-1 rounded-full font-medium ${isSmall ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'}`}
        style={{ background: 'rgba(26,128,71,0.08)', color: 'var(--success)' }}>
        <ShieldCheck className={isSmall ? 'size-2.5' : 'size-3'} />
        Basic KYC
      </span>
    )
  }
  return (
    <span className={`inline-flex items-center gap-1 rounded-full font-medium ${isSmall ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'}`}
      style={{ background: 'rgba(16,97,166,0.1)', color: '#1061a6' }}>
      <ShieldAlert className={isSmall ? 'size-2.5' : 'size-3'} />
      Full KYC{score !== undefined ? ` · ${(score / 100).toFixed(1)}/5` : ''}
    </span>
  )
}
