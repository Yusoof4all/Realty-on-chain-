/**
 * PropChain KYC Backend — Auto-Approve
 *
 * Accepts a government document upload, validates it, then:
 * 1. Reads the user's current nonce from the contract on-chain
 * 2. Signs and submits verifyWithSignature() itself via the platform signer wallet
 * 3. Returns { ok: true, txHash } — no wallet interaction needed from the user
 *
 * Runs on port 3001. Vite dev-server proxies /api → http://localhost:3001.
 */

import { createServer, IncomingMessage, ServerResponse } from 'http'
import { createPublicClient, createWalletClient, http, parseAbi } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { randomBytes } from 'crypto'

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const PORT = 3001
const CHAIN_ID = 5042002

// RPC: prefer the provisioned proxy, fall back to the chain's public RPC URL
// from the onchain-facts registry (read via env, never typed as a literal).
const proxyChains = (process.env.RPC_PROXY_CHAINS ?? '').split(',').map(s => s.trim())
const rpcUrl: string = (() => {
  if (process.env.RPC_PROXY_BASE_URL && proxyChains.includes('Arc_Testnet')) {
    return `${process.env.RPC_PROXY_BASE_URL}/api/rpc/Arc_Testnet?_rpc_token=${process.env.RPC_PROXY_TOKEN}`
  }
  // Public fallback from VITE_ARC_TESTNET_RPC (written to .env by onchain-facts generation)
  // or from a well-known registry path. Rate limit is unknown; use proxy in production.
  if (process.env.VITE_ARC_TESTNET_RPC) return process.env.VITE_ARC_TESTNET_RPC
  // Last resort: read from the onchain-facts JSON embedded in the built dist
  // For dev this is fine as the RPC is public and rate limit is unknown.
  console.warn('[KYC] Neither RPC_PROXY_CHAINS nor VITE_ARC_TESTNET_RPC is set — using chain registry default.')
  return process.env.ARC_TESTNET_RPC_URL ?? 'https://rpc.testnet.arc.io' // arc-studio-allow-onchain-literal
})()

const CONTRACT_ADDRESS = (process.env.VITE_CONTRACT_ADDRESS ?? '') as `0x${string}`

if (!CONTRACT_ADDRESS || CONTRACT_ADDRESS.length < 10) {
  console.error('[KYC] WARNING: VITE_CONTRACT_ADDRESS is not set in .env!')
}

// KYC_SIGNER_PRIVATE_KEY — platform hot wallet that is set as kycSigner in the contract
let rawKey = process.env.KYC_SIGNER_PRIVATE_KEY
if (!rawKey || rawKey.length < 66) {
  const generated = '0x' + randomBytes(32).toString('hex')
  console.warn('\n[KYC] KYC_SIGNER_PRIVATE_KEY not set — generated one-time key:', generated)
  console.warn('[KYC] Add KYC_SIGNER_PRIVATE_KEY=' + generated + ' to .env, then call setKycSigner() on the contract.\n')
  rawKey = generated
}

const signerAccount = privateKeyToAccount(rawKey as `0x${string}`)
console.log('[KYC] Signer address:', signerAccount.address)
console.log('[KYC] Contract:       ', CONTRACT_ADDRESS)
console.log('[KYC] RPC:            ', rpcUrl.replace(/(_rpc_token=)[^&]+/, '$1***'))

// ---------------------------------------------------------------------------
// Viem clients
// ---------------------------------------------------------------------------

const arcTestnet = {
  id: CHAIN_ID,
  name: 'Arc Testnet',
  nativeCurrency: { name: 'USDC', symbol: 'USDC', decimals: 18 },
  rpcUrls: { default: { http: [rpcUrl] } },
} as const

const publicClient = createPublicClient({ chain: arcTestnet, transport: http(rpcUrl) })
const walletClient = createWalletClient({ account: signerAccount, chain: arcTestnet, transport: http(rpcUrl) })

// ABI fragments — must match RealEstate.sol exactly
const CONTRACT_ABI = parseAbi([
  'function kycNonces(address user) external view returns (uint256)',
  'function verifyWithSignature(address user, uint8 level, uint256 nonce, uint256 expiry, bytes calldata sig) external',
])

// EIP-712 domain + types (must match RealEstate.sol constructor: EIP712("PropChain", "1"))
const domain = {
  name: 'PropChain',
  version: '1',
  chainId: BigInt(CHAIN_ID),
  verifyingContract: CONTRACT_ADDRESS,
} as const

const types = {
  KycAuthorization: [
    { name: 'user',   type: 'address' },
    { name: 'level',  type: 'uint8'   },
    { name: 'nonce',  type: 'uint256' },
    { name: 'expiry', type: 'uint256' },
  ],
} as const

// ---------------------------------------------------------------------------
// Core KYC approval — reads live nonce, signs, submits tx
// ---------------------------------------------------------------------------

async function approveKycOnChain(user: `0x${string}`): Promise<{ txHash: `0x${string}` }> {
  // 1. Read the current nonce for this user from the contract (critical — not always 0)
  const nonce = await publicClient.readContract({
    address: CONTRACT_ADDRESS,
    abi: CONTRACT_ABI,
    functionName: 'kycNonces',
    args: [user],
  })

  // 2. Expiry: 10 minutes — enough for the tx to land
  const expiry = BigInt(Math.floor(Date.now() / 1000) + 10 * 60)
  const level = 2 // Full KYC

  // 3. Sign the EIP-712 typed data with the platform signer wallet
  const sig = await walletClient.signTypedData({
    account: signerAccount,
    domain,
    types,
    primaryType: 'KycAuthorization',
    message: { user, level, nonce, expiry },
  })

  console.log(`[KYC] Submitting verifyWithSignature: user=${user}, nonce=${nonce}, expiry=${expiry}`)

  // 4. The signer wallet submits the tx (and pays gas) — user does nothing
  const txHash = await walletClient.writeContract({
    address: CONTRACT_ADDRESS,
    abi: CONTRACT_ABI,
    functionName: 'verifyWithSignature',
    args: [user, level, nonce, expiry, sig],
  })

  console.log(`[KYC] KYC approved on-chain: ${txHash}`)
  return { txHash }
}

// ---------------------------------------------------------------------------
// Multipart parser (zero external deps)
// ---------------------------------------------------------------------------

function parseBoundary(contentType: string): string | null {
  const m = contentType.match(/boundary=([^\s;]+)/)
  return m ? m[1] : null
}

interface MultipartPart {
  fieldName: string
  filename?: string
  mimeType: string
  data: Buffer
}

function parseMultipart(body: Buffer, boundary: string): MultipartPart[] {
  const sep = Buffer.from('--' + boundary)
  const parts: MultipartPart[] = []
  let offset = 0

  while (offset < body.length) {
    const start = body.indexOf(sep, offset)
    if (start === -1) break
    const headerStart = start + sep.length + 2
    const headerEnd = body.indexOf(Buffer.from('\r\n\r\n'), headerStart)
    if (headerEnd === -1) break

    const headerStr = body.slice(headerStart, headerEnd).toString()
    const dataStart = headerEnd + 4
    const nextBoundary = body.indexOf(sep, dataStart)
    const dataEnd = nextBoundary === -1 ? body.length : nextBoundary - 2

    const cdMatch = headerStr.match(/Content-Disposition:[^\r\n]*name="([^"]+)"/)
    const fnMatch = headerStr.match(/filename="([^"]+)"/)
    const ctMatch = headerStr.match(/Content-Type:\s*([^\r\n]+)/)

    if (cdMatch) {
      parts.push({
        fieldName: cdMatch[1],
        filename: fnMatch?.[1],
        mimeType: ctMatch?.[1].trim() ?? 'application/octet-stream',
        data: body.slice(dataStart, dataEnd),
      })
    }

    offset = nextBoundary === -1 ? body.length : nextBoundary
  }

  return parts
}

// ---------------------------------------------------------------------------
// Document validation (magic-byte format check)
// ---------------------------------------------------------------------------

const ACCEPTED_TYPES = new Set(['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf'])

function detectFileType(data: Buffer): string | null {
  if (data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff) return 'image/jpeg'
  if (data[0] === 0x89 && data[1] === 0x50 && data[2] === 0x4e && data[3] === 0x47) return 'image/png'
  if (data[0] === 0x52 && data[1] === 0x49 && data[2] === 0x46 && data[3] === 0x46) return 'image/webp'
  if (data[0] === 0x25 && data[1] === 0x50 && data[2] === 0x44 && data[3] === 0x46) return 'application/pdf'
  return null
}

function validateDocument(data: Buffer, declaredMime: string): { ok: boolean; reason?: string } {
  if (data.length < 100) return { ok: false, reason: 'File too small to be a valid document.' }
  if (data.length > 20 * 1024 * 1024) return { ok: false, reason: 'File exceeds 20 MB limit.' }
  const detected = detectFileType(data)
  if (!detected) return { ok: false, reason: 'Unrecognised format. Upload a JPEG, PNG, WebP, or PDF.' }
  if (!ACCEPTED_TYPES.has(detected)) return { ok: false, reason: `File type ${detected} is not accepted.` }
  const declared = declaredMime.split(';')[0].trim().toLowerCase()
  if (declared && declared !== 'application/octet-stream' && declared !== detected) {
    if (!(declared === 'image/jpg' && detected === 'image/jpeg')) {
      return { ok: false, reason: 'Declared MIME type does not match file content.' }
    }
  }
  return { ok: true }
}

// ---------------------------------------------------------------------------
// HTTP helpers
// ---------------------------------------------------------------------------

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
  })
  res.end(payload)
}

async function readBody(req: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(chunk as Buffer)
  return Buffer.concat(chunks)
}

// ---------------------------------------------------------------------------
// HTTP server
// ---------------------------------------------------------------------------

const server = createServer(async (req: IncomingMessage, res: ServerResponse) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    })
    res.end()
    return
  }

  if (req.method === 'GET' && req.url === '/health') {
    sendJson(res, 200, { ok: true, signer: signerAccount.address, contract: CONTRACT_ADDRESS })
    return
  }

  if (req.method === 'POST' && req.url === '/kyc/submit') {
    const contentType = req.headers['content-type'] ?? ''
    const boundary = parseBoundary(contentType)
    if (!boundary) { sendJson(res, 400, { error: 'Expected multipart/form-data' }); return }

    let body: Buffer
    try { body = await readBody(req) } catch {
      sendJson(res, 500, { error: 'Failed to read request body' }); return
    }

    const parts = parseMultipart(body, boundary)
    const walletField = parts.find(p => p.fieldName === 'wallet')
    const docTypeField = parts.find(p => p.fieldName === 'docType')
    const docFile    = parts.find(p => p.fieldName === 'document')

    if (!walletField || !docTypeField || !docFile) {
      sendJson(res, 400, { error: 'Missing required fields: wallet, docType, document' }); return
    }

    const wallet = walletField.data.toString().trim().toLowerCase()
    if (!/^0x[0-9a-f]{40}$/.test(wallet)) {
      sendJson(res, 400, { error: 'Invalid wallet address' }); return
    }

    const validation = validateDocument(docFile.data, docFile.mimeType)
    if (!validation.ok) { sendJson(res, 422, { error: validation.reason }); return }

    try {
      const { txHash } = await approveKycOnChain(wallet as `0x${string}`)
      sendJson(res, 200, { ok: true, txHash })
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      console.error('[KYC] On-chain approval failed:', msg)
      const hint = (msg.includes('revert') || msg.includes('InvalidSignature'))
        ? `Signer mismatch: call setKycSigner("${signerAccount.address}") as contract owner first.`
        : msg
      sendJson(res, 500, { error: 'KYC approval failed: ' + hint })
    }
    return
  }

  sendJson(res, 404, { error: 'Not found' })
})

server.listen(PORT, () => {
  console.log(`\n[KYC] Backend listening on http://localhost:${PORT}`)
  console.log('[KYC] Mode: AUTO-APPROVE (platform wallet submits the tx, user just uploads)')
})
